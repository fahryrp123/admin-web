/* ===== TRACKING MODULE =====
   Menampilkan lokasi HP tersembunyi di peta Leaflet (admin panel)
   ============================================================= */

const TRACKER_API     = 'https://sewamobilyuk-api.exponic.site/api/tracker';
const POLL_INTERVAL   = 10000; // 10 detik (mengurangi beban web)
const OFFLINE_TIMEOUT = 30;    // detik – tracker dianggap offline

let trackingMap      = null;
let trackerMarkers   = {};    // { trackerId: L.marker }
let trackingInterval = null;
let initialFitDone   = false;

/* ───────────────────────────────────────────────────────
   MAIN LOAD
─────────────────────────────────────────────────────── */
async function loadTracking() {
  initTrackingMap();
  await refreshTrackers();
  // Auto-refresh setiap 10 detik
  if (trackingInterval) clearInterval(trackingInterval);
  trackingInterval = setInterval(refreshTrackers, POLL_INTERVAL);
  // Tombol refresh manual
  const btn = document.getElementById('btn-refresh-map');
  if (btn) btn.onclick = refreshTrackers;
}

/* ───────────────────────────────────────────────────────
   INISIALISASI PETA LEAFLET
─────────────────────────────────────────────────────── */
function initTrackingMap() {
  if (trackingMap) return; // sudah diinit
  initialFitDone = false;

  trackingMap = L.map('map', {
    center: [-6.2, 106.816], // Jakarta sebagai default
    zoom: 12,
    zoomControl: true,
  });

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19,
  }).addTo(trackingMap);
}

/* ───────────────────────────────────────────────────────
   AMBIL DATA TRACKER DARI BACKEND
─────────────────────────────────────────────────────── */
async function refreshTrackers() {
  try {
    const res  = await apiFetch('/tracker/locations');
    const json = res.data || {};
    const trackers = json.data || [];

    renderTrackerList(trackers);
    renderTrackerMarkers(trackers);
  } catch (e) {
    console.error('Tracking refresh error:', e);
    document.getElementById('tracking-list').innerHTML =
      `<div style="text-align:center;padding:20px;color:#ef4444;font-size:13px;">
        ⚠️ Gagal memuat data tracker.<br>Pastikan server berjalan.
      </div>`;
  }
}

/* ───────────────────────────────────────────────────────
   RENDER DAFTAR TRACKER (sidebar kiri)
─────────────────────────────────────────────────────── */
function renderTrackerList(trackers) {
  const el = document.getElementById('tracking-list');

  // Update counters
  const onlineCount  = trackers.filter(isOnline).length;
  const offlineCount = trackers.length - onlineCount;
  const onlineEl  = document.getElementById('stat-tracker-online');
  const offlineEl = document.getElementById('stat-tracker-offline');
  const updateEl  = document.getElementById('tracker-last-update');
  if (onlineEl)  onlineEl.textContent  = onlineCount;
  if (offlineEl) offlineEl.textContent = offlineCount;
  if (updateEl)  updateEl.textContent  = 'Update: ' + new Date().toLocaleTimeString('id-ID');

  if (!trackers.length) {
    el.innerHTML = `
      <div style="text-align:center;padding:24px;color:#64748b;font-size:13px;line-height:1.7;">
        <div style="font-size:32px;margin-bottom:8px;">📡</div>
        <div>Belum ada tracker aktif.</div>
        <div style="font-size:12px;margin-top:6px;">Klik "Generate Link" di bawah<br>untuk setup HP tersembunyi.</div>
      </div>`;
    return;
  }

  el.innerHTML = trackers.map(t => {
    const online     = isOnline(t);
    const lastSeen   = t.last_seen_at ? timeSince(t.last_seen_at) : 'Belum pernah';
    const battColor  = t.battery > 50 ? '#22c55e' : t.battery > 20 ? '#eab308' : '#ef4444';
    const battIcon   = t.battery > 50 ? '🟢' : t.battery > 20 ? '🟡' : '🔴';

    return `
      <div class="tracker-card ${online ? 'tracker-online' : 'tracker-offline'}"
           onclick="focusTracker(${t.id})"
           data-tracker-id="${t.id}"
           style="cursor:pointer;">
        <div class="tracker-card-header">
          <div class="tracker-name">
            <span class="tracker-dot ${online ? 'dot-green' : 'dot-red'}"></span>
            ${escHtml(t.car_label || 'Mobil #' + t.car_id)}
          </div>
          <span class="tracker-status-badge ${online ? 'badge-success' : 'badge-danger'}">
            ${online ? '● Online' : '○ Offline'}
          </span>
        </div>
        <div class="tracker-card-body">
          <div class="tracker-meta">
            <span>📍 ${t.lat ? t.lat.toFixed(5) + ', ' + t.lng.toFixed(5) : '–'}</span>
          </div>
          <div class="tracker-meta" style="margin-top:4px;">
            <span style="color:#64748b;font-size:11px;">⏱ ${lastSeen}</span>
            ${t.battery != null ? `<span style="color:${battColor};font-size:11px;">${battIcon} ${t.battery}%</span>` : ''}
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;margin-top:10px;">
          <div style="display:flex;gap:6px;">
            <button class="btn btn-soft-secondary btn-sm" style="flex:1;"
                    onclick="event.stopPropagation();viewTrackerSetup('${t.car_id}', '${escHtml(t.car_label || '').replace(/'/g,'\\\'')}', '${t.device_token}')"
                    title="Lihat Setup QR & Token">
              <i class="fas fa-qrcode"></i> Lihat Setup QR
            </button>
            <button class="btn btn-danger btn-sm"
                    onclick="event.stopPropagation();deactivateTracker(${t.id})"
                    title="Nonaktifkan tracker">
              <i class="fas fa-trash-alt"></i>
            </button>
          </div>
          <button class="btn btn-soft-secondary btn-sm" style="width:100%;font-size:11px;"
                  onclick="event.stopPropagation();viewTrackerHistory('${t.car_id}', '${t.device_token}')">
            <i class="fas fa-route"></i> Lihat Histori Rute
          </button>
        </div>
      </div>`;
  }).join('');
}

/* ───────────────────────────────────────────────────────
   RENDER MARKER DI PETA
─────────────────────────────────────────────────────── */
function renderTrackerMarkers(trackers) {
  if (!trackingMap) return;

  const validIds = new Set(trackers.map(t => t.id));

  // Hapus marker yang tidak ada lagi
  Object.keys(trackerMarkers).forEach(id => {
    if (!validIds.has(Number(id))) {
      trackingMap.removeLayer(trackerMarkers[id]);
      delete trackerMarkers[id];
    }
  });

  trackers.forEach(t => {
    if (!t.lat || !t.lng) return;
    const online = isOnline(t);
    const latlng = [parseFloat(t.lat), parseFloat(t.lng)];

    const icon = L.divIcon({
      html: `
        <div class="map-tracker-icon ${online ? 'map-icon-online' : 'map-icon-offline'}">
          <svg viewBox="0 0 24 24" fill="white" width="18" height="18">
            <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99z"/>
          </svg>
          ${online ? '<div class="map-ping-ring"></div>' : ''}
        </div>`,
      className: '',
      iconSize:   [40, 40],
      iconAnchor: [20, 40],
      popupAnchor:[0, -42],
    });

    const popupHtml = buildPopupHtml(t, online);

    if (trackerMarkers[t.id]) {
      // Update posisi marker yang sudah ada
      trackerMarkers[t.id].setLatLng(latlng);
      trackerMarkers[t.id].setIcon(icon);
      trackerMarkers[t.id].getPopup()?.setContent(popupHtml);
    } else {
      // Buat marker baru
      const marker = L.marker(latlng, { icon })
        .addTo(trackingMap)
        .bindPopup(popupHtml, { maxWidth: 240 });
      trackerMarkers[t.id] = marker;
    }
  });

  // Fit bounds jika ada marker (Hanya dilakukan sekali di awal agar tidak mengganggu geser peta)
  const validMarkers = Object.values(trackerMarkers);
  if (!initialFitDone && validMarkers.length > 0) {
    if (validMarkers.length === 1) {
      trackingMap.setView(validMarkers[0].getLatLng(), 15);
    } else {
      const group = L.featureGroup(validMarkers);
      trackingMap.fitBounds(group.getBounds().pad(0.2));
    }
    initialFitDone = true;
  }
}

/* ───────────────────────────────────────────────────────
   POPUP HTML
─────────────────────────────────────────────────────── */
function buildPopupHtml(t, online) {
  const lastSeen  = t.last_seen_at ? timeSince(t.last_seen_at) : '–';
  const battStr   = t.battery != null ? t.battery + '%' : '–';
  const speedStr  = t.speed   != null ? t.speed.toFixed(1) + ' km/h' : '–';
  const accStr    = t.accuracy != null ? t.accuracy.toFixed(0) + ' m' : '–';

  return `
    <div style="font-family:Inter,sans-serif;min-width:200px;">
      <div style="font-weight:700;font-size:14px;margin-bottom:8px;display:flex;align-items:center;gap:6px;">
        🚗 ${escHtml(t.car_label || 'Mobil #' + t.car_id)}
        <span style="font-size:10px;padding:2px 6px;border-radius:99px;background:${online?'#dcfce7':'#fee2e2'};color:${online?'#15803d':'#991b1b'};font-weight:600;">
          ${online ? 'Online' : 'Offline'}
        </span>
      </div>
      <div style="font-size:12px;color:#475569;display:grid;gap:4px;">
        <div>📍 <b>${t.lat ? parseFloat(t.lat).toFixed(6) : '–'}</b>, <b>${t.lng ? parseFloat(t.lng).toFixed(6) : '–'}</b></div>
        <div>⚡ Kecepatan: <b>${speedStr}</b></div>
        <div>🎯 Akurasi: <b>${accStr}</b></div>
        <div>🔋 Baterai: <b>${battStr}</b></div>
        <div>⏱ Update: <b>${lastSeen}</b></div>
      </div>
      <a href="https://maps.google.com/?q=${t.lat},${t.lng}" target="_blank"
         style="display:block;margin-top:10px;text-align:center;background:#3b82f6;color:white;padding:6px 10px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:600;">
        Buka di Google Maps
      </a>
    </div>`;
}

/* ───────────────────────────────────────────────────────
   FOKUS KE MARKER
─────────────────────────────────────────────────────── */
function focusTracker(id) {
  const marker = trackerMarkers[id];
  if (!marker) return;
  trackingMap.setView(marker.getLatLng(), 16, { animate: true });
  marker.openPopup();
  // Highlight card
  document.querySelectorAll('.tracker-card').forEach(c => c.classList.remove('tracker-selected'));
  const card = document.querySelector(`[data-tracker-id="${id}"]`);
  if (card) card.classList.add('tracker-selected');
}

/* ───────────────────────────────────────────────────────
   LIHAT HISTORI RUTE PERJALANAN
─────────────────────────────────────────────────────── */
let historyPolyline = null;
async function viewTrackerHistory(carId, deviceToken) {
  try {
    toast('Memuat histori rute...', 'info');
    const res = await apiFetch('/tracker/history/' + carId);
    if (!res || !res.ok) throw new Error('Gagal memuat histori');
    
    // Filter histori hanya untuk sesi HP (device_token) yang dipilih
    const allHistory = res.data?.data || [];
    const historyData = deviceToken ? allHistory.filter(h => h.device_token === deviceToken) : allHistory;

    if (historyData.length < 2) {
      toast('Belum cukup data rute untuk sesi HP ini.', 'warning');
      return;
    }

    // Hapus polyline lama jika ada
    if (historyPolyline) {
      trackingMap.removeLayer(historyPolyline);
    }

    // Hapus marker start/end lama jika ada
    if (window.routeStartMarker) trackingMap.removeLayer(window.routeStartMarker);
    if (window.routeEndMarker) trackingMap.removeLayer(window.routeEndMarker);

    // Ekstrak koordinat dan filter titik yang terlalu berdekatan (menghilangkan efek coretan/GPS jitter)
    const rawLatlngs = historyData.map(h => [parseFloat(h.lat), parseFloat(h.lng)]);
    const latlngs = [];
    
    if (rawLatlngs.length > 0) {
      latlngs.push(rawLatlngs[0]); // Selalu masukkan titik awal
      let lastPoint = L.latLng(rawLatlngs[0]);
      
      for (let i = 1; i < rawLatlngs.length; i++) {
        const currentPoint = L.latLng(rawLatlngs[i]);
        // Hanya gambar garis jika pergerakan lebih dari 15 meter (menghapus coretan saat HP diam)
        if (currentPoint.distanceTo(lastPoint) > 15) {
          latlngs.push(rawLatlngs[i]);
          lastPoint = currentPoint;
        }
      }
    }

    // Gambar garis solid yang lebih mulus (tanpa putus-putus)
    historyPolyline = L.polyline(latlngs, {
      color: '#3b82f6',
      weight: 4,
      opacity: 0.7,
      smoothFactor: 2.5,
      lineJoin: 'round'
    }).addTo(trackingMap);

    // Tambahkan penanda Titik Awal (Hijau) dan Titik Akhir (Merah)
    if (latlngs.length > 0) {
      window.routeStartMarker = L.circleMarker(latlngs[0], { radius: 5, color: '#fff', weight: 2, fillColor: '#22c55e', fillOpacity: 1 }).addTo(trackingMap).bindPopup('<b style="color:#16a34a">Awal Perjalanan</b>');
      window.routeEndMarker = L.circleMarker(latlngs[latlngs.length - 1], { radius: 5, color: '#fff', weight: 2, fillColor: '#ef4444', fillOpacity: 1 }).addTo(trackingMap).bindPopup('<b style="color:#dc2626">Akhir Perjalanan</b>');
    }

    // Zoom ke rute
    trackingMap.fitBounds(historyPolyline.getBounds().pad(0.1));
    toast('Berhasil memuat rute perjalanan mobil!', 'success');
  } catch (e) {
    toast('Error: ' + e.message, 'error');
  }
}

/* ───────────────────────────────────────────────────────
   GENERATE LINK TRACKER
─────────────────────────────────────────────────────── */
async function openGenerateTokenModal() {
  openModal('tracker-gen-modal');
  document.getElementById('gen-result').style.display = 'none';
  document.getElementById('gen-car-select').parentElement.style.display = '';
  
  const customLabelInput = document.getElementById('gen-custom-label');
  if (customLabelInput) {
    customLabelInput.parentElement.style.display = '';
    customLabelInput.value = '';
  }
  document.getElementById('gen-token-btn').style.display = '';
  
  const sel = document.getElementById('gen-car-select');
  sel.innerHTML = '<option value="">Memuat data mobil...</option>';
  
  try {
    // Tarik data mobil dari API
    const res = await Cars.list();
    if (!res || !res.ok) throw new Error();
    const cars = window.extractList(res);
    
    // Ambil daftar tracker yang sudah aktif
    const trRes = await apiFetch('/tracker/locations');
    const trJson = trRes.data || {};
    const activeCarIds = new Set((trJson.data || []).map(t => String(t.car_id)));

    if (!cars || !cars.length) {
      sel.innerHTML = '<option value="">Tidak ada data mobil</option>';
      return;
    }

    sel.innerHTML = '<option value="">-- Pilih Mobil --</option>' + cars.map(c => {
      const isTracked = activeCarIds.has(String(c.id));
      const statusText = isTracked ? ' (Sudah Ditracking)' : '';
      return `<option value="${c.id}" ${isTracked ? 'disabled' : ''}>${escHtml(c.name_car || c.model || 'Mobil')} - ${escHtml(c.plate_number)}${statusText}</option>`;
    }).join('');
  } catch (e) {
    sel.innerHTML = '<option value="">Gagal memuat data mobil</option>';
  }
}

async function doGenerateToken() {
  const sel = document.getElementById('gen-car-select');
  const carId = sel.value;
  let carLabel = sel.options[sel.selectedIndex]?.text.replace(' (Sudah Ditracking)', '');
  
  const customLabelInput = document.getElementById('gen-custom-label');
  if (customLabelInput && customLabelInput.value.trim() !== '') {
    carLabel = customLabelInput.value.trim() + ' (' + carLabel + ')';
  }

  if (!carId) { toast('Silakan pilih mobil terlebih dahulu!', 'error'); return; }

  const btn = document.getElementById('gen-token-btn');
  btn.disabled = true;
  btn.textContent = 'Generating...';

  try {
    const res = await apiFetch('/tracker/generate-token', {
      method: 'POST',
      body: JSON.stringify({ car_id: carId, car_label: carLabel }),
    });
    const json = res.data || {};
    if (!res.ok) throw new Error(json.message || 'Gagal generate token');

    const token = json.device_token;
    // Gunakan origin web (exponic.site) agar selalu dinamis dan menghindari error localhost dari backend
    const url = 'https://exponic.site/tracker.html?token=' + token + '&car_id=' + carId + '&label=' + encodeURIComponent(carLabel) + '&autostart=1';
    
    document.getElementById('gen-result').style.display = '';
    document.getElementById('gen-tracker-url').textContent = url;
    document.getElementById('gen-tracker-url').href = url;
    
    const tokenEl = document.getElementById('gen-tracker-token');
    if (tokenEl) tokenEl.textContent = token;
    
    document.getElementById('gen-qr-img').src =
      'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent(url);

    toast('Link & Token tracker berhasil dibuat!', 'success');
    
    // Auto-refresh list tracker di background supaya mobil baru langsung muncul
    refreshTrackers();
  } catch (e) {
    toast('Error: ' + e.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Generate Link Tracker';
  }
}

window.viewTrackerSetup = function(carId, carLabel, token) {
  openModal('tracker-gen-modal');
  
  // Hide form inputs
  document.getElementById('gen-car-select').parentElement.style.display = 'none';
  const customLabelInput = document.getElementById('gen-custom-label');
  if (customLabelInput) customLabelInput.parentElement.style.display = 'none';
  document.getElementById('gen-token-btn').style.display = 'none';
  
  // Show result
  document.getElementById('gen-result').style.display = '';
  
  const url = 'https://exponic.site/tracker.html?token=' + token + '&car_id=' + carId + '&label=' + encodeURIComponent(carLabel) + '&autostart=1';
  document.getElementById('gen-tracker-url').textContent = url;
  document.getElementById('gen-tracker-url').href = url;
  
  const tokenEl = document.getElementById('gen-tracker-token');
  if (tokenEl) tokenEl.textContent = token;
  
  document.getElementById('gen-qr-img').src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent(url);
}

function copyTrackerUrl() {
  const url = document.getElementById('gen-tracker-url').textContent;
  navigator.clipboard.writeText(url).then(() => toast('Link disalin!', 'success'));
}

function copyTrackerToken() {
  const tokenEl = document.getElementById('gen-tracker-token');
  if (tokenEl) {
    navigator.clipboard.writeText(tokenEl.textContent).then(() => toast('Token disalin!', 'success'));
  }
}

/* ───────────────────────────────────────────────────────
   NONAKTIFKAN TRACKER
─────────────────────────────────────────────────────── */
async function deactivateTracker(id) {
  confirmAction('Nonaktifkan Tracker?', 'Tracker akan dinonaktifkan dan dihapus dari peta.', async () => {
    const res = await apiFetch('/tracker/' + id, { method: 'DELETE' });
    if (res && res.ok) {
      toast('Tracker dinonaktifkan.', 'success');
      // Hapus marker dari peta
      if (trackerMarkers[id]) {
        trackingMap.removeLayer(trackerMarkers[id]);
        delete trackerMarkers[id];
      }
      refreshTrackers();
    } else {
      toast('Gagal menonaktifkan tracker.', 'error');
    }
  });
}

/* ───────────────────────────────────────────────────────
   HELPERS
─────────────────────────────────────────────────────── */
function isOnline(t) {
  if (!t.last_seen_at) return false;
  const diff = (Date.now() - new Date(t.last_seen_at).getTime()) / 1000;
  return diff < OFFLINE_TIMEOUT;
}

function timeSince(dateStr) {
  const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diff < 5)   return 'Baru saja';
  if (diff < 60)  return diff + 'd yang lalu';
  if (diff < 3600) return Math.floor(diff/60) + 'm yang lalu';
  if (diff < 86400) return Math.floor(diff/3600) + 'j yang lalu';
  return Math.floor(diff/86400) + ' hari yang lalu';
}

function escHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Export ke window agar bisa dipanggil dari HTML
window.loadTracking       = loadTracking;
window.refreshTrackers    = refreshTrackers;
window.focusTracker       = focusTracker;
window.viewTrackerHistory = viewTrackerHistory;
window.openGenerateTokenModal = openGenerateTokenModal;
window.doGenerateToken    = doGenerateToken;
window.viewTrackerSetup   = window.viewTrackerSetup;
window.copyTrackerUrl     = copyTrackerUrl;
window.deactivateTracker  = deactivateTracker;
