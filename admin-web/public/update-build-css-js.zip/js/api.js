/* ===== API MODULE ===== */
const API_BASE = 'https://sewamobilyuk-api.exponic.site/api';
const IMG_BASE = 'https://sewamobilyuk-api.exponic.site/storage/';

function getToken() { return localStorage.getItem('smy_token'); }

function authHeaders(isForm = false) {
  const h = { 'Accept': 'application/json' };
  if (getToken()) h['Authorization'] = 'Bearer ' + getToken();
  if (!isForm) h['Content-Type'] = 'application/json';
  return h;
}

async function apiFetch(path, options = {}) {
  const url = API_BASE + path;
  const isForm = options.isForm;
  delete options.isForm;
  try {
    const res = await fetch(url, { headers: authHeaders(isForm), ...options });
    if (res.status === 401) {
      localStorage.removeItem('smy_token');
      localStorage.removeItem('smy_user');
      window.location.href = '/login';
      return;
    }
    const text = await res.text();
    try { return { ok: res.ok, status: res.status, data: JSON.parse(text) }; }
    catch { return { ok: res.ok, status: res.status, data: text }; }
  } catch(e) {
    return { ok: false, status: 0, data: { message: 'Gagal terhubung ke server.' } };
  }
}

/* ---- AUTH ---- */
const Auth = {
  login: (login, password) =>
    apiFetch('/login', { method: 'POST', body: JSON.stringify({ login, password }) }),
  logout: () => apiFetch('/logout', { method: 'POST' }),
  profile: () => apiFetch('/showProfile'),
};

/* ---- CARS  ----
   GET    /show             → list all cars
   GET    /show/{id}        → car detail
   POST   /add-car          → create (multipart)
   POST   /updateCar/{id}    → update (multipart)
   DELETE /deleteCar/{id}   → delete
*/
const Cars = {
  list: (p = 1) => apiFetch('/show?page=' + p),
  listAll: async () => {
    let all = [], cp = 1;
    while(true) {
      const r = await apiFetch('/show?page=' + cp);
      let list = [];
      if (r.data?.data?.data && Array.isArray(r.data.data.data)) list = r.data.data.data;
      else if (Array.isArray(r.data?.data)) list = r.data.data;
      else if (Array.isArray(r.data)) list = r.data;
      
      if (!list.length) break;
      all = all.concat(list);
      
      const d = r.data?.data;
      if (d && d.last_page && cp >= d.last_page) break;
      if (!d || !d.last_page) break;
      cp++;
    }
    return { ok: true, data: all };
  },
  get:  (id) => apiFetch('/show/' + id),
  create: (fd) => apiFetch('/add-car', { method: 'POST', body: fd, isForm: true }),
  update: (id, fd) => apiFetch('/updateCar/' + id + '?_method=PUT', { method: 'POST', body: fd, isForm: true }),
  delete: (id) => apiFetch('/deleteCar/' + id, { method: 'DELETE' }),
};

/* ---- RESERVATIONS ----
   GET   /history-reservation        → list (customer own / admin all)
   GET   /all-reservation            → admin: all reservations (may exist)
   PATCH /cancel-reserv/{id}      → cancel
   PATCH /approve-refund/{id}        → approve refund
*/
const Rentals = {
  list: () => apiFetch('/history-reservation'),
  listAll: () => apiFetch('/reservations'),
  cancel: (id) => apiFetch('/cancel-reserv/' + id, { method: 'PATCH' }),
  approveRefund: (id) => apiFetch('/approve-refund/' + id, { method: 'PATCH', body: JSON.stringify({ id }) }),
  approve: (id) => apiFetch('/approve-reservasi/' + id, { method: 'PATCH', body: JSON.stringify({ id }) }),
  reject: (id, reason) => apiFetch('/rejected-reservation/' + id, { method: 'PATCH', body: JSON.stringify({ id, reason }) })
};

/* ---- USERS ----
   GET    /showProfile              → current user profile
   POST   /updateProfile            → update own profile
   DELETE /delete-account            → delete own account
   (no admin user list endpoint in docs – we'll use what's available)
*/
const Users = {
  list: () => apiFetch('/customer-profile'),
  get: (id) => apiFetch('/customer-profile'), // Admin API doesn't have a specific customer detail endpoint, falling back to list (or customer-profile handles it?)
  delete: (id) => apiFetch('/delete-account'), // Using available delete-account
  profile: () => apiFetch('/showProfile'),
  updateProfile: (fd) => apiFetch('/updateProfile', { method: 'POST', body: fd, isForm: true }),
};

/* ---- IMAGE URL ---- */
function imgUrl(path) {
  if (!path) return null;
  if (path.startsWith('http')) return path;
  return IMG_BASE + path;
}

/* ---- TOAST ---- */
function toast(msg, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const icons = { success:'fa-check-circle', error:'fa-times-circle', info:'fa-info-circle', warning:'fa-exclamation-triangle' };
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<i class="fas ${icons[type]||icons.info} toast-icon"></i><span class="toast-msg">${msg}</span>`;
  container.appendChild(el);
  setTimeout(() => { el.classList.add('hide'); setTimeout(() => el.remove(), 300); }, 3200);
}

/* ---- FORMAT ---- */
function formatRp(n) {
  if (n == null || n === '') return '-';
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}
function formatDate(d, useRelative = false) {
  if (!d) return '-';
  const dateObj = new Date(d);
  if (useRelative) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const target = new Date(dateObj);
    target.setHours(0,0,0,0);
    const diffTime = target - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return '<span style="color:#eab308;font-weight:700;">Hari Ini</span>';
    if (diffDays === 1) return '<span style="color:#3b82f6;font-weight:700;">Besok</span>';
    if (diffDays === -1) return '<span style="color:#ef4444;font-weight:700;">Kemarin</span>';
    if (diffDays > 1 && diffDays <= 7) return `<span style="font-weight:600;">${diffDays} Hari Lagi</span>`;
    if (diffDays < -1) return `<span style="color:#ef4444;font-weight:700;">Telat ${Math.abs(diffDays)} Hari</span>`;
  }
  return dateObj.toLocaleDateString('id-ID', { day:'2-digit', month:'short', year:'numeric' });
}
function formatDateTime(d) {
  if (!d) return '-';
  return new Date(d).toLocaleString('id-ID', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
}
function ucFirst(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : '-'; }

function statusBadge(status) {
  const map = {
    pending:    ['badge-warning',   'fa-clock',            'Menunggu'],
    'Waiting_payment': ['badge-warning', 'fa-clock',       'Menunggu Pembayaran'],
    waiting_payment: ['badge-warning', 'fa-clock',         'Menunggu Pembayaran'],
    confirmed:  ['badge-info',      'fa-check',            'Dikonfirmasi'],
    active:     ['badge-success',   'fa-car',              'Aktif'],
    completed:  ['badge-secondary', 'fa-flag-checkered',   'Selesai'],
    cancelled:  ['badge-danger',    'fa-times',            'Dibatalkan'],
    rejected:   ['badge-danger',    'fa-ban',              'Ditolak'],
    available:  ['badge-success',   'fa-check-circle',     'Tersedia'],
    rented:     ['badge-orange',    'fa-key',              'Disewa'],
    maintenance:['badge-warning',   'fa-wrench',           'Servis'],
    none:       ['badge-secondary', 'fa-minus-circle',     'Tidak Ada'],
    approved:   ['badge-success',   'fa-check-double',     'Disetujui'],
  };
  const [cls, icon, label] = map[status] || ['badge-secondary','fa-circle', ucFirst(status)];
  return `<span class="badge ${cls}"><i class="fas ${icon}"></i>${label}</span>`;
}

function avatarLetter(name) {
  if (!name) return '?';
  return name.split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase();
}

/* ---- CONFIRM ---- */
function confirmAction(title, msg, onConfirm, danger = true) {
  const overlay = document.getElementById('confirm-overlay');
  document.getElementById('confirm-icon').innerHTML  = danger ? '⚠️' : 'ℹ️';
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-msg').textContent   = msg;
  const okBtn = document.getElementById('confirm-ok');
  okBtn.className = 'btn ' + (danger ? 'btn-danger' : 'btn-primary');
  okBtn.textContent = 'Ya, Lanjutkan';
  overlay.classList.add('open');
  okBtn.onclick = () => { overlay.classList.remove('open'); onConfirm(); };
}

/* ---- CAR FIELD HELPERS ---- */
// Map API car object to display-friendly keys
function carDisplayName(c) { return c.name_car || c.name || '-'; }
function carPlate(c) { return c.plate_number || c.plat || '-'; }
function carStatus(c) { return c.availability_status || c.status || 'available'; }
function carPrice(c) { return c.price || c.price_per_day || 0; }
function carYear(c) { return c.year_of_car || c.year || '-'; }
function carPassengers(c) { return c.passenger_capacity || c.seat_capacity || '-'; }
