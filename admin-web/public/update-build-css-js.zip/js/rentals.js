/* ===== RENTALS MODULE ===== */
let allRentals = [];

async function loadRentals(page = 1) {
  rentalsPage = page;
  document.getElementById('rentals-loading').style.display = 'flex';
  
  // Fetch rentals and cars in parallel to map car details
  const [res, carsRes] = await Promise.all([
    Rentals.listAll().catch(() => Rentals.list()),
    Cars.list()
  ]);
  
  document.getElementById('rentals-loading').style.display = 'none';
  allRentals = extractList(res);
  const cars = extractList(carsRes);
  
  // Attach car data to rentals since API returns data_car_id
  allRentals.forEach(r => {
    r.car = cars.find(c => c.id === r.data_car_id) || {};
  });

  updateRentalStats();
  setupRentalFilters();
  renderRentals();
}

function updateRentalStats() {
  const todayStr = new Date().toISOString().split('T')[0];
  const totalToday = allRentals.filter(r => (r.start_date || '').startsWith(todayStr) || (r.end_date || '').startsWith(todayStr)).length;
  const pending = allRentals.filter(r => {
    const s = (r.reservations_status || r.payment_status || 'pending').toLowerCase();
    return s === 'pending' || s.includes('waiting');
  }).length;
  const active = allRentals.filter(r => {
    const s = (r.reservations_status || r.payment_status || '').toLowerCase();
    return s === 'active' || s === 'ongoing' || s === 'approved';
  }).length;
  const income = allRentals.reduce((sum, r) => {
    const s = (r.reservations_status || r.payment_status || '').toLowerCase();
    if (s === 'active' || s === 'ongoing' || s === 'completed' || s === 'approved') {
      return sum + (Number(r.total_price) || 0);
    }
    return sum;
  }, 0);

  if(document.getElementById('rentals-stat-today')) {
    document.getElementById('rentals-stat-today').textContent = totalToday;
    document.getElementById('rentals-stat-pending').textContent = pending;
    document.getElementById('rentals-stat-active').textContent = active;
    document.getElementById('rentals-stat-income').textContent = formatRp(income);
  }
}

function getFilteredRentals() {
  const q = (document.getElementById('rental-search').value || '').toLowerCase();
  return allRentals.filter(r => {
    const name = (r.user?.name || r.name || '').toLowerCase();
    const car = (r.car?.name || r.car?.brand || '').toLowerCase();
    const code = String(r.id || '').toLowerCase();
    const matchQ = !q || name.includes(q) || car.includes(q) || code.includes(q);
    
    // Status matching
    const status = (r.reservations_status || r.payment_status || 'pending').toLowerCase();
    const matchStatus = !rentalStatusFilter || status === rentalStatusFilter.toLowerCase();
    
    return matchQ && matchStatus;
  });
}

function renderRentals() {
  const filtered = getFilteredRentals();
  const start = (rentalsPage - 1) * PER_PAGE;
  const slice = filtered.slice(start, start + PER_PAGE);
  const tbody = document.getElementById('rentals-body');
  if (!slice.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><i class="fas fa-calendar-times"></i><h3>Tidak ada reservasi</h3><p>Belum ada data atau tidak sesuai filter.</p></div></td></tr>`;
    document.getElementById('rentals-pagination').innerHTML = '';
    return;
  }
  tbody.innerHTML = slice.map((r, i) => {
    const end = new Date(r.end_date); end.setHours(0,0,0,0);
    const today = new Date(); today.setHours(0,0,0,0);
    const isOngoing = (r.reservations_status === 'approved' || r.reservations_status === 'ongoing' || r.reservations_status === 'active');
    
    let countdownText = '';
    let bgStyle = '';
    if (isOngoing) {
      const diffTime = end - today;
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (diffDays < 0) {
        countdownText = `<div class="text-overdue">Terlambat ${Math.abs(diffDays)} Hari</div>`;
        bgStyle = 'background-color:#fef2f2; border-left: 3px solid #ef4444;';
      } else if (diffDays === 0) {
        countdownText = `<div class="text-today">Selesai Hari Ini</div>`;
      }
    }
    
    return `<tr style="${bgStyle}">
    <td style="color:#94a3b8;font-size:12px;">#${r.id || (start + i + 1)}</td>
    <td><div style="display:flex;align-items:center;gap:10px;">
      <div class="avatar">${avatarLetter(r.user?.name || r.name || 'U')}</div>
      <div>
        <div style="font-weight:600;font-size:13px;">${r.user?.name || r.name || 'Pengguna #' + r.user_id}</div>
        <div style="font-size:11px;color:#94a3b8;">${r.user?.email || r.email || ''}</div>
      </div>
    </div></td>
    <td><div style="font-weight:600;">${r.car?.name_car || r.car?.name || '-'}</div>
      <div style="font-size:11px;color:#94a3b8;">${r.car?.plate_number || r.car?.plat || ''}</div>
    </td>
    <td>${formatDate(r.start_date, true)}</td>
    <td>${formatDate(r.end_date, true)} ${countdownText}</td>
    <td style="font-weight:700;color:#f97316;">${formatRp(r.total_price)}</td>
    <td>${statusBadge(r.reservations_status || r.payment_status || 'pending')}</td>
    <td>
      <div style="display:flex;gap:6px;">
        <button class="btn btn-secondary btn-icon btn-sm" title="Detail" onclick="viewRental(${r.id})"><i class="fas fa-eye"></i></button>
        ${(r.reservations_status === 'pending' || !r.reservations_status) ? `
          <button class="btn btn-success btn-icon btn-sm" title="Setujui" onclick="approveRental(${r.id})"><i class="fas fa-check"></i></button>
          <button class="btn btn-danger btn-icon btn-sm" title="Tolak" onclick="rejectRental(${r.id})"><i class="fas fa-times"></i></button>
        ` : ''}
      </div>
    </td>
  </tr>`; }).join('');
  renderPagination('rentals-pagination', filtered.length, rentalsPage, PER_PAGE, 'loadRentals');
}

function setupRentalFilters() {
  document.getElementById('rental-search').oninput = () => { rentalsPage = 1; renderRentals(); };
  document.querySelectorAll('.rental-tab').forEach(btn => {
    btn.onclick = () => {
      rentalStatusFilter = btn.dataset.status;
      document.querySelectorAll('.rental-tab').forEach(b => { b.classList.remove('active', 'btn-primary'); b.classList.add('btn-secondary'); });
      btn.classList.add('active', 'btn-primary'); btn.classList.remove('btn-secondary');
      loadRentals(1);
    };
  });
}

function statusBadge(st) {
  if(!st) return '-';
  const l = st.toLowerCase();
  if(l.includes('waiting') || l === 'pending') return '<span class="badge-pill pill-warning">Menunggu</span>';
  if(l === 'approved') return '<span class="badge-pill pill-primary">Disetujui</span>';
  if(l === 'active' || l === 'ongoing' || l === 'sedang disewa') return '<span class="badge-pill pill-success">Aktif</span>';
  if(l === 'completed' || l === 'selesai') return '<span class="badge-pill pill-secondary">Selesai</span>';
  if(l === 'cancelled' || l === 'dibatalkan' || l === 'rejected') return '<span class="badge-pill pill-danger">Batal</span>';
  return `<span class="badge-pill pill-secondary">${st}</span>`;
}

window.viewRental = async function(id) {
  const r = allRentals.find(x => String(x.id) === String(id)) || {};
  const car = r.car || {};
  const user = r.user || {};
  const img = imgUrl(car.image || car.photo);

  const ktpUrl = imgUrl(r.ktp || r.foto_ktp || r.image_ktp || user.ktp || user.foto_ktp || user.image_ktp);
  const simUrl = imgUrl(r.sim || r.foto_sim || r.image_sim || user.sim || user.foto_sim || user.image_sim);
  
  // Payment proofs
  let paymentHtml = '';
  if (r.payment && r.payment.proof_of_payment) {
    const pf = imgUrl(r.payment.proof_of_payment);
    paymentHtml = `<div style="margin-top:16px;border-top:1px solid var(--border);padding-top:16px;">
      <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;margin-bottom:8px;">Bukti Pembayaran</div>
      <div class="proof-card">
        <img src="${pf}" onclick="window.open('${pf}','_blank')">
        <span>Struk Transfer</span>
      </div>
    </div>`;
  }

  document.getElementById('rental-drawer-content').innerHTML = `
    <div style="padding:24px;">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:24px;">
        <div>
          <h2 style="margin:0 0 4px 0; font-size:24px;">#${r.id}</h2>
          <div style="color:#64748b; font-size:13px;">${formatDate(r.created_at, true)}</div>
        </div>
        ${statusBadge(r.reservations_status || r.status || 'pending')}
      </div>
      
      <div style="background:white; padding:16px; border-radius:12px; border:1px solid var(--border); margin-bottom:16px;">
        <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;margin-bottom:12px;">Pelanggan</div>
        <div style="display:flex;align-items:center;gap:12px;">
          <div class="avatar" style="width:48px;height:48px;font-size:18px;">${avatarLetter(user.name || 'U')}</div>
          <div>
            <div style="font-weight:700; font-size:15px;">${user.name || '-'}</div>
            <div style="font-size:13px;color:#64748b;">${user.email || ''}</div>
            <div style="font-size:13px;color:#64748b;">${user.phone || user.no_hp || '-'}</div>
          </div>
        </div>
        
        ${(ktpUrl || simUrl) ? `
        <div class="proof-image-grid">
          ${ktpUrl ? `<div class="proof-card"><img src="${ktpUrl}" onclick="window.open('${ktpUrl}','_blank')"><span>KTP</span></div>` : ''}
          ${simUrl ? `<div class="proof-card"><img src="${simUrl}" onclick="window.open('${simUrl}','_blank')"><span>SIM</span></div>` : ''}
        </div>` : ''}
      </div>

      <div style="background:white; padding:16px; border-radius:12px; border:1px solid var(--border); margin-bottom:16px;">
        <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;margin-bottom:12px;">Kendaraan & Waktu</div>
        <div style="display:flex;align-items:center;gap:12px; margin-bottom:16px;">
          ${img ? `<img src="${img}" style="width:72px;height:52px;object-fit:cover;border-radius:6px;">` : `<div class="car-img-placeholder" style="width:72px;height:52px;font-size:24px;"><i class="fas fa-car"></i></div>`}
          <div>
            <div style="font-weight:700; font-size:15px;">${car.name || car.brand || '-'}</div>
            <div style="font-size:13px;color:#64748b; font-family:monospace;">${car.license_plate || car.plat || '-'}</div>
          </div>
        </div>
        
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
          ${row('Mulai Sewa', formatDate(r.start_date, true))}
          ${row('Selesai Sewa', formatDate(r.end_date, true))}
        </div>
      </div>
      
      <div style="background:white; padding:16px; border-radius:12px; border:1px solid var(--border);">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div style="font-size:13px; color:#64748b;">Total Pembayaran</div>
          <div style="font-size:20px; font-weight:800; color:var(--primary);">${formatRp(r.total_price)}</div>
        </div>
        ${paymentHtml}
      </div>
    </div>
  `;

  const actions = document.getElementById('rental-drawer-actions');
  const isPending = r.reservations_status === 'pending' || r.reservations_status === 'Waiting_payment' || r.reservations_status === 'waiting_payment' || r.status === 'pending' || r.status === 'Waiting_payment' || !r.reservations_status;
  
  if (isPending) {
    actions.innerHTML = `
      <button class="btn btn-danger" onclick="rejectRental(${r.id},true)"><i class="fas fa-times"></i> Tolak</button>
      <button class="btn btn-success" onclick="approveRental(${r.id},true)"><i class="fas fa-check"></i> Setujui</button>
    `;
  } else {
    actions.innerHTML = `
      <button class="btn btn-secondary" onclick="closeRentalDetail()" style="width:100%;">Tutup Panel</button>
    `;
  }
  
  document.getElementById('rental-detail-overlay').classList.add('open');
  document.getElementById('rental-detail-drawer').classList.add('open');
  document.body.style.overflow = 'hidden';
};

window.closeRentalDetail = function() {
  document.getElementById('rental-detail-overlay').classList.remove('open');
  document.getElementById('rental-detail-drawer').classList.remove('open');
  document.body.style.overflow = '';
};

function row(label, value) {
  return `<div><div style="font-size:11px;color:#94a3b8;font-weight:600;margin-bottom:2px;">${label}</div><div style="font-size:13px;font-weight:500;">${value}</div></div>`;
}

window.approveRental = async function(id, fromModal = false) {
  confirmAction('Setujui Reservasi', 'Apakah Anda yakin ingin menyetujui reservasi ini?', async () => {
    const res = await Rentals.approve(id);
    if (res?.ok) { 
      toast('Reservasi disetujui!'); 
      if (fromModal) {
        closeModal('rental-modal-overlay');
        closeRentalDetail();
      }
      loadRentals(rentalsPage); 
    }
    else toast(res?.data?.message || 'Gagal menyetujui.', 'error');
  }, false);
};

window.rejectRental = async function(id, fromModal = false) {
  document.getElementById('reject-reason-input').value = '';
  openModal('reject-modal-overlay');
  
  document.getElementById('btn-submit-reject').onclick = async () => {
    const reason = document.getElementById('reject-reason-input').value;
    if (!reason.trim()) { toast('Alasan penolakan wajib diisi!', 'error'); return; }
    
    const btn = document.getElementById('btn-submit-reject');
    btn.disabled = true;
    btn.textContent = 'Memproses...';
    
    const res = await Rentals.reject(id, reason);
    
    btn.disabled = false;
    btn.textContent = 'Tolak Reservasi';
    
    if (res?.ok) { 
      toast('Reservasi berhasil ditolak.', 'warning'); 
      closeModal('reject-modal-overlay');
      if (fromModal) {
        closeModal('rental-modal-overlay'); 
        closeRentalDetail();
      }
      loadRentals(rentalsPage); 
    } else {
      toast(res?.data?.message || 'Gagal menolak.', 'error');
    }
  };
};

window.loadRentals = loadRentals;
